"""
generate_data.py
-----------------
Generates a synthetic telecom-style customer churn dataset used for
Task 2: Predictive Analysis using Machine Learning
(ELiteTech Intern - Data Analytics Internship).

10,000 customer records with realistic, correlated features so that a
trained model has genuine signal to learn from (not pure noise).
"""

import numpy as np
import pandas as pd
import os

np.random.seed(42)
N = 10_000
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# --- base features ---
tenure_months = np.random.randint(1, 73, size=N)
monthly_charge = np.round(np.random.normal(65, 20, size=N).clip(15, 150), 2)
contract_type = np.random.choice(
    ["Month-to-Month", "One Year", "Two Year"], size=N, p=[0.55, 0.25, 0.20]
)
internet_service = np.random.choice(
    ["DSL", "Fiber Optic", "No Internet"], size=N, p=[0.35, 0.45, 0.20]
)
tech_support = np.random.choice(["Yes", "No"], size=N, p=[0.35, 0.65])
num_support_calls = np.random.poisson(1.5, size=N)
payment_method = np.random.choice(
    ["Electronic Check", "Mailed Check", "Bank Transfer", "Credit Card"], size=N
)
paperless_billing = np.random.choice(["Yes", "No"], size=N, p=[0.6, 0.4])
senior_citizen = np.random.choice([0, 1], size=N, p=[0.84, 0.16])
partner = np.random.choice(["Yes", "No"], size=N, p=[0.48, 0.52])
total_charges = np.round(monthly_charge * tenure_months *
                          np.random.uniform(0.9, 1.05, size=N), 2)

# --- build churn probability from a realistic logistic combination ---
contract_risk = np.select(
    [contract_type == "Month-to-Month", contract_type == "One Year",
     contract_type == "Two Year"],
    [0.9, 0.3, 0.05]
)
support_risk = np.where(tech_support == "No", 0.35, -0.25)
fiber_risk = np.where(internet_service == "Fiber Optic", 0.25, 0.0)
calls_risk = num_support_calls * 0.18
tenure_protect = -0.02 * tenure_months
echeck_risk = np.where(payment_method == "Electronic Check", 0.3, 0.0)

logit = (
    -1.2 + contract_risk + support_risk + fiber_risk +
    calls_risk + tenure_protect + echeck_risk +
    np.random.normal(0, 0.6, size=N)          # noise
)
churn_prob = 1 / (1 + np.exp(-logit))
churn = (np.random.rand(N) < churn_prob).astype(int)

df = pd.DataFrame({
    "customer_id": np.arange(1, N + 1),
    "tenure_months": tenure_months,
    "monthly_charge": monthly_charge,
    "total_charges": total_charges,
    "contract_type": contract_type,
    "internet_service": internet_service,
    "tech_support": tech_support,
    "num_support_calls": num_support_calls,
    "payment_method": payment_method,
    "paperless_billing": paperless_billing,
    "senior_citizen": senior_citizen,
    "partner": partner,
    "churn": churn,
})

# a little realistic messiness
missing_idx = np.random.choice(N, size=int(N * 0.01), replace=False)
df.loc[missing_idx, "total_charges"] = np.nan

out_path = os.path.join(OUTPUT_DIR, "customer_churn.csv")
df.to_csv(out_path, index=False)
print(f"Wrote {out_path} ({len(df):,} rows)")
print(f"Churn rate: {df['churn'].mean():.2%}")
