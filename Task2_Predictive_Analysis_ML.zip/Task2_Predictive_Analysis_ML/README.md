# Task 2 — Predictive Analysis using Machine Learning
**ELiteTech Intern — Data Analytics Internship**

## Objective
Build a machine learning model (classification) to predict customer churn
based on account and usage attributes, demonstrating feature selection,
model training, and evaluation.

## Contents
| File | Description |
|---|---|
| `generate_data.py` | Generates the synthetic 10,000-row telecom-style customer churn dataset (`data/customer_churn.csv`), with realistic correlated churn signal. |
| `Predictive_Analysis_ML.ipynb` | Main deliverable notebook — EDA, cleaning, feature selection (ANOVA F-test), training Logistic Regression + Random Forest, and evaluation. |
| `requirements.txt` | Python dependencies. |
| `churn_eda.png`, `feature_selection.png`, `model_evaluation.png`, `rf_feature_importance.png` | Charts exported from the notebook. |

## How to reproduce
```bash
pip install -r requirements.txt
python generate_data.py          # creates data/customer_churn.csv
jupyter nbconvert --to notebook --execute --inplace Predictive_Analysis_ML.ipynb
```

## Approach
1. **Data cleaning** — median imputation of missing `total_charges`, grouped by contract type.
2. **Feature selection** — `SelectKBest` with ANOVA F-test ranks encoded features by predictive power for churn.
3. **Model training** — Logistic Regression (baseline, interpretable) and Random Forest (captures non-linear interactions), both wrapped in `sklearn` pipelines with proper scaling/encoding.
4. **Evaluation** — Accuracy, Precision, Recall, F1, ROC-AUC, confusion matrix, and classification report on a held-out 20% test set.

## Key Insights
1. **Random Forest** outperforms Logistic Regression on ROC-AUC and F1,
   capturing non-linear interactions between features.
2. **Top churn drivers:** month-to-month contracts, low tenure, high
   number of support calls, and no tech support.
3. **Business action:** target month-to-month customers with <12 months
   tenure and 2+ support calls for proactive retention offers.
4. Billing/payment method contributes comparatively little predictive
   signal versus contract and support-related features.

## Deliverable status
✅ Notebook demonstrating feature selection, model training, and
evaluation, as required by the task instructions.
